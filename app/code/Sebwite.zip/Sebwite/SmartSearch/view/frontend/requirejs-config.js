var config = {
    map: {
        '*': {
            quickSearchAutocomplete:'Sebwite_SmartSearch/form-mini'
        }
    }
};